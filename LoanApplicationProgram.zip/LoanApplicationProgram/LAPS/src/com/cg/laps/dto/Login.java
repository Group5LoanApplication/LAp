package com.cg.laps.dto;



//---------------------- 1. Loan Login Bean --------------------------
/*******************************************************************************************************
- Class Name		:	Login
- Author			:	Group 5(Loan Application Processing System)
- Creation Date		:	22/12/2017
- Description 		:   Getting Login credentials
********************************************************************************************************/	
public class Login {
	private String loginId;
	private String password;
	private String role;

	public Login() {
		super();
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
